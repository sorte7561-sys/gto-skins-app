# GTO Skins — Android

Aplicativo Android que abre o site oficial do GTO Skins dentro de um WebView.

**Site:** https://gto-skins.onrender.com/

## Como gerar o APK

1. Instale o Android Studio em um computador.
2. Abra esta pasta no Android Studio.
3. Aguarde o Gradle sincronizar e baixar as dependências.
4. Use **Build > Build APK(s)** para gerar o APK de teste.
5. Para uma versão final assinada, use **Build > Generate Signed App Bundle / APK**.

## Observações

- O site não é alterado por este projeto.
- O app usa o mesmo endereço do site.
- O botão voltar navega pelo histórico do site.
- Downloads iniciados pelo site usam o gerenciador de downloads do Android.
- O ícone usado no projeto é o logo criado para o GTO Skins.
